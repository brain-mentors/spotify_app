class Category {
  String name;
  String imageURL;
  Category(this.name, this.imageURL);
}
