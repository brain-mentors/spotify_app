import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spotify_app/screens/app.dart';

void main() {
  runApp(MaterialApp(
      title: 'Spotify Clone',
      debugShowCheckedModeBanner: false,
      home: MyApp()));
}
